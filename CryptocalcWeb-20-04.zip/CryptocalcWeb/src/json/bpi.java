package json;

public class bpi {

	protected usd USD;

	public usd getUsd() {
		return USD;
	}

	public void setUsd(usd usd) {
		this.USD = usd;
	}

}