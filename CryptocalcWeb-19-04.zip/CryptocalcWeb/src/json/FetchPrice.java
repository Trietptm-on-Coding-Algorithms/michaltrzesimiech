package json;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

import json.Ethereum;

import com.google.gson.Gson;

public class FetchPrice {

	public static double FetchPrice() {

		Gson gson = new Gson();

		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(
					"P:\\calcEther.txt"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Ethereum eth = gson.fromJson(br, Ethereum.class);
		
		double price = Float.parseFloat(eth.getEthereumTicker().getPrice());
		
		return price;
		
	}
		
}
